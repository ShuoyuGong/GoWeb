package leveldb

const DBName = "leveldb"
