package alils

import (
	_ "github.com/beego/beego/v2/core/logs/alils"
)
